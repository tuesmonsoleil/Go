import json
import random
import itertools

# 創建一個包含數字的列表
digits = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9']

# 使用 itertools.permutations 產生所有的四位數字的組合
perms = list(itertools.permutations(digits, 5))

# 將結果從元組轉換成字串
data = {}

def compare(value, n):
    a = 0
    b = 0
    for i in range(5):
        if value[i] == n[i]:
            a += 1
        elif value[i] in n:
            b += 1
    return a, b

# db
def get_users():
    # read json and return
    with open('data/user.json') as f:
        users = json.load(f)
    return users

def reset(code): # code
    global data
    data[name] = {
        'candidates' : [''.join(perm) for perm in perms],
        'last_guess' : '12345'
    }

def guess_algo(a,b,code): # code
    global data
    eliminate_list = []
    for n in data[name]['candidates']:
        res = compare(data[name]['last_guess'],n)
        if (a,b) != res:
            eliminate_list.append(n)

    data[name]['candidates'] = [item for item in data[name]['candidates'] if item not in eliminate_list]
    data[name]['last_guess'] = random.choice(data[name]['candidates'])
    
    return data[name]['last_guess']