from peewee import *

db = SqliteDatabase('users.db')

class User(Model):
    name = CharField()
    age = IntegerField()
    phone = CharField()
    
    class Meta:
        database = db
        
db.connect()
db.create_tables([User])

# 新增
user = User(name='小明', age=18, phone='0912-345-678')
user.save()

# 修改
user = User.get(User.name == '小明')
user.age = 20
user.save()

# 查詢
for user in User.select():
    print(user.name,user.age, user.phone)

# 刪除  
user = User.get(User.name=='小明')
user.delete_instance()
