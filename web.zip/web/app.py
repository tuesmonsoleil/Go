from flask import Flask, request,jsonify,render_template,send_file,redirect
from flask_login import LoginManager, UserMixin, login_user, login_required, logout_user, current_user
from utils import *
import json
import math

class CustomFlask(Flask):
    jinja_options = Flask.jinja_options.copy()
    jinja_options.update(dict(
        variable_start_string='<%',
        variable_end_string='%>',
        comment_start_string='<#',
        comment_end_string='#>',
    ))


app = CustomFlask(__name__)
app.config['SECRET_KEY'] = 'mysecretkeygjsfdlgjhidtiohjruiotht9wyt8corchtuhukl'
login_manager = LoginManager()
login_manager.init_app(app)
login_manager.login_view = 'login'

users = get_users()

class User(UserMixin):
    def __init__(self, user_id, username, password,role):
        self.id = user_id
        self.username = username
        self.password = password
        self.role = role

# db
@login_manager.user_loader
def load_user(user_id):
    for user in users:
        if user['id'] == int(user_id):
            return User(user['id'], user['username'], user['password'],user['role'])
    return None


# db
@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        user = None

        for u in users:
            if u['username'] == username and u['password'] == password:
                user = User(u['id'], u['username'], u['password'],u['role'])
                break

        if user:
            login_user(user)
            return redirect('/test')
        else:
            return redirect('/login')

    return render_template('login.html')

@app.route('/')
def root():
    return redirect('/login')

@app.route('/logout')
@login_required
def logout():
    logout_user()
    return redirect('/login')

@app.route("/test")
@login_required
def test():
    return render_template('test.html',user={'name':current_user.username,'id':current_user.id,'role':current_user.role})


@app.route("/api_test")
def api_test():
    return jsonify({"version":"v1.0"})

@app.route("/118_test")
def api_118():
    return jsonify({"version":"118"})



# 要修改成再多接收一個流水號
@app.route("/guess/<a>/<b>/code") # /guess/a/b/code
@login_required
def guess(a,b,code): # (a,b,code)
    a = int(a)
    b = int(b)
    # name = current_user.username # no need
    ans = guess_algo(a,b,code) # a, b, code
    return jsonify({"result":ans})

@app.route("/guess")
@login_required
def render_guess():
    return render_template('guess.html')

@app.route("/reset_candid/code") # /code
@login_required
def reset_candid(code): # (code)
    # name = current_user.username # no need
    reset(code) # code
    return jsonify({"result":"success"})



if __name__ == "__main__":
    app.run(host='0.0.0.0', port=55555)