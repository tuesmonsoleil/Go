let makeRequestSync = function (method, url) {
    var xhr = new XMLHttpRequest();
    xhr.open(method, url,false);
    xhr.onload = function () {
        if (this.status !== 200) {
            alert(JSON.parse(xhr.response).error)
        }
    }
    //xhr.setRequestHeader('APIKEY', APIKEY);
    xhr.send();
    return JSON.parse(xhr.response);
};

let makeRequestSyncPost = function (url, data) {
    var xhr = new XMLHttpRequest();
    xhr.open('POST', url,false);
    xhr.onload = function () {
        if (this.status !== 200) {
            alert(JSON.parse(xhr.response).error)
        }
    }
    //xhr.setRequestHeader('APIKEY', APIKEY);
    xhr.send(data);
    // the data should be like this: "name=John&location=Boston"
    return JSON.parse(xhr.response);
}

let makeRequestSyncPostJson = function (url, data) {
    var xhr = new XMLHttpRequest();
    xhr.open('POST', url,false);
    xhr.onload = function () {
        if (this.status !== 200) {
            alert(JSON.parse(xhr.response).error)
        }
    }
    xhr.setRequestHeader('Content-Type', 'application/json');
    xhr.send(data);
    // the data should json format like this: {"name":"John", "location":"Boston"}
    return JSON.parse(xhr.response);
}

let makeRequestPostJson = function (url, data, callback) {
    var xhr = new XMLHttpRequest();
    xhr.open('POST', url);
    xhr.onload = function () {
        callback(JSON.parse(xhr.response));
    };
    xhr.onerror = function () {
        callback(JSON.parse('{"res":"請求失敗","ans":"請求失敗"}'));
    };
    xhr.setRequestHeader('Content-Type', 'application/json');
    xhr.send(data);
}